# MCP 工具定义完整性：7 台官方 server 的跨版本测量

> 客户端批准了一个 tool，下一次 `tools/list` 时它还是同一个吗？我们用完整对象 digest、order 探针和官方 conformance 做了一次本地测量。

## 1. 问题

MCP 的 `tools/list` 可以在运行中变化。很多客户端做 tool 批准时，只记住四个字段：

```text
name / description / inputSchema / annotations
```

但一个 Tool 对象还有 `title`、`outputSchema`，2025-11-25 的 schema 里还有 `execution.taskSupport`；server 级别还有 `instructions`。这些字段都不在四字段 digest 里。

这不是漏洞。协议允许 server 改工具；问题是 host 能不能把“变了”显示给用户，并在重新批准前不调用。

MCP 2.x 正在被更多 client / server 采用，但 tool 定义不是 immutable 的。server 可以在两次 `tools/list` 之间改 description、schema、annotations，甚至只改 instructions；client 如果没有完整定义，就不知道自己批准的是什么。

## 2. 方法

- 7 台官方 reference server，1.x / 2.x，stdio，本地运行。
- 两个 era：2025-11-25（`initialize` + session）与 2026-07-28（`server/discover`，stateless）。
- 三层检查：
  1. **定义 digest**：`serverInfo` + `instructions` + 完整 Tool 对象，按 name 排序，RFC 8785 JCS，SHA-256。
  2. **order**：连续 `tools/list` 的工具名顺序；4 个 tool × 24 种固定排列，再加轮转。
  3. **2×2 交叉**：我们的检查 × 官方 conformance fixtures。

7 台 server 的 tool 数如下（2.x legacy 是 `initialize` 路径，modern 是 `server/discover` 路径）：

| server | 1.x | 2.x legacy | 2.x modern |
|---|---:|---:|---:|
| everything | 13 | 16 | 22 |
| filesystem | 14 | 14 | 14 |
| memory | 9 | 9 | 9 |
| sequentialthinking | 1 | 1 | 1 |
| fetch | 1 | 1 | 1 |
| git | 12 | 12 | 12 |
| time | 2 | 2 | 2 |

在 2.x 的两个 era 之间，只有 `everything` 不同；其余 6 台一致。1.x 与 2.x 之间也只有 `everything` 的 tool 数从 13 变为 16。

## 3. 结果

### 3.1 era 是粘的

7/7 都支持 2026-07-28。但第一条请求会提交连接的 era：

```text
legacy 先发  -> server/discover 返回 -32601
modern 先发  -> initialize 返回 -32022
```

在 2.x 的两个 era 之间，6/7 提供相同 tool 集；`everything` 不同：legacy 16 个，modern 22 个，instructions 从 2004 字符变为 3537 字符。

### 3.2 四字段 digest 的盲区

2025-11-25 的 Tool schema 有 `execution.taskSupport`，2026-07-28 把 tasks 移到 extension。2.x 的兼容路径里这个字段仍可能出现（也可能被服务端省略）。

我们的 drift fixture 把 `execution` 从 `null` 改成 `{"taskSupport": "required"}`：四字段 digest 不变，完整 digest 变。instructions-only 变化同理。

完整 digest 的输入不是四个字段，而是：

```text
JCS({
  digestVersion,
  server: {name, version},
  instructions,
  tools: [完整 Tool 对象, 按 name 排序]
})
```

再拼上 domain separator 做 SHA-256。JCS 的作用是让不同语言、不同 host 对同一个对象算出同一个字节序列；没有它，key 顺序、空白、数字格式都会让 digest 漂移。只要对象里任何一个字段变了，digest 就会变；四字段子集不会。

`title` 和 `outputSchema` 也在完整对象里、不在四字段里；四字段子集天生看不到它们。

### 3.3 order 是另一个属性

完整 digest 按 name 排序，所以 order 不在 digest 里。

```text
4 个 tool × 24 种固定排列  -> 24/24 PASS
轮转顺序                  -> order WARNING，definition STABLE
```

4 个 tool 的排列是 4! = 24。固定排列重复三次，digest 必须完全一致；轮转顺序则保持定义 digest 不变，只让 order 签名变化。这样能把“内容变了”和“顺序变了”分开。

order 变化影响 UI、缓存和 diff 展示，但不是定义变化。把它混进定义 digest，会把“顺序抖了”误报成“工具变了”。

### 3.4 与官方 conformance 的 2×2

7 个目标：

| 目标 | 官方 conformance | 我们的检查 |
|---|---|---|
| `everything` | PASS | clean |
| `rotated-order` | WARNING | order WARNING |
| `invalid-tool-names` | WARNING | 不覆盖 |
| `stripped-schema` | FAIL | 不覆盖 |
| `no-dns-rebinding` | FAIL | 不覆盖 |
| `no-caching-hints` | FAIL | 不覆盖 |
| `drift-fixture` | PASS（无此检查） | definition CHANGED |

如果按 fixture 算“同结果”，只有 2/7 相同；但这不是准确率，因为每个 fixture 测的是不同属性。按属性算，真正的重叠只有 clean baseline 和 order 两项。

重叠属性 2/2 一致，但覆盖不同：官方有 4 个我们没有的 spec 检查；我们有一个官方没有的 drift 检查。两边是互补，不是互相替代。

## 4. 这意味着什么

如果 host 只用四字段 pin，已批准的 tool 可以在 `execution`、`title`、`outputSchema` 或 server `instructions` 上变化，而不触发重新批准。server 也可以保持所有 Tool digest 不变，只改 instructions。

这不是“server 能改工具”的漏洞——协议本来就允许。问题是 host 有没有能力看见变化。把完整性可见性做好，不等于把 server 当成敌人；它只是让批准这件事有意义。

对 host 来说，最小实现是：

1. 批准时存完整定义，不只存四个字段；
2. 每次 `tools/list` 重算，变化时显示 diff，未批准前不调用；
3. 不依赖 `list_changed`；通知只是提示，不是证据；
4. 把 scope 和 `protocolVersion` 存进 pin key，跨 era 不比较。

建议：

```text
pin 完整对象 + serverInfo + instructions
以 (authorization scope, protocolVersion) 为比较键
把 list_changed 当 re-fetch hint，不当证据
order 单独记录，不混进定义 digest
```

## 5. 复现

数据集（ModelScope）：`<MODELSCOPE_DATASET>`（MIT 许可）



```bash
NODE=/path/to/node \
SERVER=/path/to/server-everything/dist/index.js \
python3 checks/minimal_repro.py

python3 checks/drift_http_fixture.py &
python3 checks/mcp_order_probe.py --url http://127.0.0.1:3020/mcp --probes 3
```

建议先跑 `minimal_repro.py`，再跑 drift fixture，最后看 24 排列；不要一上来跑全量矩阵。

预期：

```text
10/10 checks passed
definition: CHANGED
order: INFO
```

## 6. 边界

7 台官方 reference server、本地 stdio、本地 fixture；没有公网 endpoint，没有生产 server。不是漏洞报告，也不是对所有 MCP server 的统计。数据日期 2026-11-04。

三个限制：

- 只测了 7 台官方 reference server，不代表整个生态；
- drift / instructions 变化是本地 fixture 构造的，不是对某个生产 server 的观测；
- order 检查是 SHOULD 级提醒，不是 MUST；不同 server 可以有不同顺序。

1.x 矩阵 35/35、2.x 21/21 次启动 digest 一致；order 在 1.x 7/7、2.x 7/7 都没有 warning。这些是“稳定”的基线，不是“所有 server 都稳定”的结论。

如果这个方向对你有用，欢迎在评论区指出 order / drift 检查的误报和漏报；也可以直接看数据集里的代码和原始 JSON。

## 7. 结论

完整对象 digest 比四字段 digest 多看见 `execution`、`title`、`outputSchema`、`instructions`；order 和 definition 要分开；conformance 和完整性检查是互补的。对 client 来说，最小改动是批准时存完整定义、每次重算、变化时显示 diff。

这篇文章适合做 MCP client / gateway / registry 的开发者，以及需要给 tool 批准做审计的团队。
