---
license: mit
task: other
tags:
- MCP
- tool-definition
- JCS
- conformance
- agent
language:
- zh
- en
---

> 完整包也以 `mcp-tool-definition-integrity-2026-11.zip` 提供；也可以直接使用下列文件。

# MCP 工具定义完整性测试集（2026-11-04）

## 简介

本数据集记录一次本地测量：MCP 的 tool 定义在 1.x / 2.x、legacy / modern 两个 era 之间是否稳定，以及客户端常用的“四字段 digest”会漏掉哪些字段。

测量对象是 7 台官方 reference server（stdio，本地运行），不是公网扫描，也不是漏洞报告。

配套文章：`ARTICLE.md`

## 文件

| 文件 | 内容 |
|---|---|
| `MCP-checkup-2026-11-04-v2.md` | 完整技术包：结论、最小复现、全量代码、2×2 交叉实验 |
| `mcp-checkup-2026-11-04.json` | 基线：版本、tool 数、JCS digest |
| `checks/` | 可直接跑的 Python 检查（10 项最小复现、order 探针、drift fixture） |
| `tool-pinning-server-context.diff` | 给公开 *Client-Held Tool Definition Pinning* 草案的补充 patch |
| `ARTICLE.md` | 中文说明文章 |

## 互动页面

https://www.modelscope.cn/studios/BZYS17Mintstar/mcp-definition-integrity

页面包含文章、2×2 交叉表和三个可现场跑的检查按钮。

## 快速开始

```bash
# 10 项检查；需要 Node + server-everything
NODE=/path/to/node \
SERVER=/path/to/server-everything/dist/index.js \
python3 checks/minimal_repro.py

# 定义漂移 + order 探针；纯 Python
python3 checks/drift_http_fixture.py &
python3 checks/mcp_order_probe.py --url http://127.0.0.1:3020/mcp --probes 3
```

预期：

```text
10/10 checks passed
definition: CHANGED
order: INFO
```

## 测量范围

```text
7 台官方 reference server：everything / filesystem / memory /
  sequentialthinking / fetch / git / time
1.x 与 2.x；2.x 内 legacy initialize 与 modern server/discover 两条路径
本地 stdio；本地 HTTP drift fixture
无公网 endpoint、无生产 server、无凭据
```

## 关键结果

- 7/7 支持 2026-07-28；era 是 connection-sticky 的：legacy 先发会让 `server/discover` 返回 `-32601`，modern 先发会让 `initialize` 返回 `-32022`。
- 2.x 的两个 era 之间，6/7 的 tool 集相同；`everything` 不同：legacy 16、modern 22。
- 四字段 digest（`name` / `description` / `inputSchema` / `annotations`）看不到 `execution`、`title`、`outputSchema` 和 server `instructions`；完整对象 JCS digest 能看到。
- 4 个 tool × 24 种固定排列全部 PASS；轮转顺序触发 order WARNING，但 definition STABLE。
- 2×2 交叉：双方 clean 1、双方都报 1、官方-only 4、我们-only 1（drift fixture）。

## 脱敏与边界

```text
已移除：家目录、主机名、用户名、仓库账号、commit、评论 ID、邮箱、临时路径
保留：公开包名/版本、公开 issue 编号、127.0.0.1、夹具假 token
没有公网扫描；没有对任何生产 server 的指控
order 检查是 SHOULD 级提醒，不是 MUST
drift / instructions 变化由本地 fixture 构造，不代表某个生产 server 的观测
```

## License

MIT. See `LICENSE`.

## 引用

如果引用本数据集，请注明：

```text
MCP tool-definition integrity test vectors, 2026-11-04.
ModelScope dataset: https://www.modelscope.cn/datasets/BZYS17Mintstar/mcp-tool-definition-integrity-2026-11
```

优先使用本数据集或 Gitee 镜像。
